const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');

router.post('/signup', async (req,res)=>{
  const user = await User.create(req.body);
  res.json(user);
});

router.post('/login', async (req,res)=>{
  const user = await User.findOne({email:req.body.email});
  if(!user) return res.status(400).send("User not found");
  const token = jwt.sign({id:user._id}, process.env.JWT_SECRET);
  res.json({token});
});

module.exports = router;