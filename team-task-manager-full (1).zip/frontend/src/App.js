import React from 'react';
export default function App(){
  return <h1>Team Task Manager</h1>
}